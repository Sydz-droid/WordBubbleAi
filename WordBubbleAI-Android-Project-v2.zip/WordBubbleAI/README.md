# WordBubble AI (Android)

Floating bubble tekaan untuk permainan Hot or Cold / Contexto. Reka bentuk soft blue + dark navy. Projek asal Java Android (Android 8.0+).

## Fungsi

- Floating bubble boleh digerakkan di atas game atau app lain.
- Butang Scan menangkap imej skrin melalui **MediaProjection** dengan keizinan Android.
- OCR Google ML Kit membaca word + nombor rank pada skrin. OCR dijalankan pada peranti.
- 3 cadangan perkataan: Gemini 3.8 Flash dengan API key milik pengguna, atau Datamuse percuma sebagai fallback (kurang tepat).
- Auto Scan 8 / 15 / 30 saat, berjalan selagi sesi screen capture masih aktif.
- Scan tidak menyimpan fail tangkapan skrin.

## Penting

Projek **bukan APK yang sudah dibina / diuji pada telefon**. Sumber projek disediakan untuk dibina dengan Android Studio atau GitHub Actions. Tidak boleh menjanjikan jawapan nombor 1, kerana susunan rank bergantung pada kata rahsia permainan.

Aplikasi ialah Android, bukan iOS. Android 14+ biasanya memerlukan persetujuan screen capture baharu apabila sesi bermula. Android kadangkala memilih rakaman satu app sahaja. App yang menghalang screen capture tidak boleh dibaca.

## Build dengan GitHub Actions

1. Cipta repository baharu dan upload **isi folder projek** (bukan fail ZIP sebagai satu fail) ke root repository.
2. Pada tab `Actions`, pilih `Build WordBubble APK` kemudian `Run workflow`.
3. Selepas job `build` berjaya, buka `Artifacts` → `WordBubble-AI-APK` → download zip yang mengandungi `app-debug.apk`.
4. Extrak zip di telefon, kemudian pasang APK (Android mungkin meminta izin `Install unknown apps`).

GitHub Actions menghasilkan APK **debug** yang ditandatangani dengan kunci debug dari runner, sesuai untuk ujian peribadi, bukan Play Store. Jika memasang versi seterusnya daripada build berlainan, mungkin perlu uninstall versi lama disebabkan tandatangan berbeza.

## Build dalam Android Studio

Open folder `WordBubbleAI`, sync Gradle, Build → Build APK(s). SDK Android 35 dan JDK 17 digunakan.

## Guna

1. Buka aplikasi, masukkan Gemini API key jika ada. Biarkan kosong untuk mode percuma.
2. Tekan `Aktifkan floating bubble`. Izinkan `Display over other apps` dan kemudian izin rakaman skrin.
3. Buka permainan. Sentuh bubble ✦, tekan `Scan`, atau aktifkan `Auto ON`.
4. Lihat 3 perkataan. Pilih sendiri untuk ditaip ke dalam game.
5. Sentuh `Tutup bubble & hentikan scan` untuk tamat sesi.

## Privasi

Screenshot dianalisis secara tempatan oleh ML Kit, tidak disimpan. Hanya perkataan petunjuk dan ranking dihantar kepada Google Gemini (jika API key dimasukkan), atau Datamuse, untuk cadangan. Sila jangan scan skrin yang mengandungi maklumat peribadi kerana OCR berusaha mengenal pasti petunjuk, dan bukan semua kesilapan pengecaman boleh dijangka. API key disimpan di SharedPreferences pada telefon, bukan di source code. Untuk keselamatan tinggi, gunakan proksi backend bagi melindungi API key.

## Kes hadapan

Parser perlu disesuaikan jika UI permainan berbeza (contohnya teks rank jauh dari perkataan). Network dan OCR mungkin gagal pada skrin tertentu. Tidak ada kaedah bypass screen capture DRM atau app secure.
