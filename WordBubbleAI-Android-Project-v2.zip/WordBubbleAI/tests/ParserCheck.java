import com.wordbubble.ai.ClueParser;
import java.util.Arrays;
public class ParserCheck {
  public static void main(String[] args) {
    var rows = ClueParser.parseRows(Arrays.asList("Guess the word", "burger 2", "fries 312", "apple 999", "Pizza"));
    if (rows.size() != 3 || !rows.get(0).word.equals("burger") || rows.get(0).rank != 2 || rows.get(1).rank!=312) throw new AssertionError(rows.toString());
    System.out.println("Parser test OK: " + ClueParser.format(rows));
  }
}
