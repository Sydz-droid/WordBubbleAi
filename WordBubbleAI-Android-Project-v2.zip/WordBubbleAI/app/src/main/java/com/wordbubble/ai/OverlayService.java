package com.wordbubble.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OverlayService extends Service {
    public static final String ACTION_START = "com.wordbubble.ai.START";
    private static final String CHANNEL_ID = "bubble_scan";
    private WindowManager windowManager;
    private WindowManager.LayoutParams winParams;
    private LinearLayout root, panel;
    private TextView status, cluesLabel, answerLabel;
    private Button bubble, autoButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextRecognizer recognizer;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private boolean auto = false, busy = false, expanded = false;
    private int intervalMs = 8000;
    private final Runnable autoLoop = new Runnable() {
        @Override public void run() {
            if (auto) { if (!busy) scan(); handler.postDelayed(this, intervalMs); }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        intervalMs = getSharedPreferences("settings", MODE_PRIVATE).getInt("interval", 8) * 1000;
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        if (projection != null) {updateStatus("Bubble sudah aktif. Hentikan dulu sebelum mula sesi baru."); return START_NOT_STICKY;}
        ensureNotification();
        try {
            startForeground(22, buildNotification());
            int code = intent.getIntExtra("code", 0);
            Intent captureData;
            if (Build.VERSION.SDK_INT >= 33) captureData = intent.getParcelableExtra("capture_data", Intent.class);
            else captureData = intent.getParcelableExtra("capture_data");
            if (code == 0 || captureData == null) {stopSelf(); return START_NOT_STICKY;}
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(code, captureData);
            if (projection == null) throw new IllegalStateException("Tiada screen projection");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    handler.post(() -> { updateStatus("Kebenaran screen capture tamat. Buka app untuk mula semula."); stopSelf(); });
                }
            }, handler);
            setupCapture();
            showOverlay();
        } catch (Exception ex) { stopSelf(); }
        return START_NOT_STICKY;
    }

    private void ensureNotification() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "WordBubble scan", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Screen capture aktif apabila WordBubble dibuka"); nm.createNotificationChannel(channel);
        }
    }
    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return b.setContentTitle("WordBubble AI aktif")
            .setContentText("Floating bubble sedang berjalan • sentuh untuk tetapan")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(pending).setOngoing(true).build();
    }
    private void setupCapture() {
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        int w = dm.widthPixels, h = dm.heightPixels;
        imageReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3);
        virtualDisplay = projection.createVirtualDisplay("WordBubbleScreen", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, handler);
    }

    private void showOverlay() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        bubble = Ui.button(this, "✦", true); bubble.setTextSize(25);
        bubble.setBackground(Ui.shape(this, Ui.BLUE, 80)); bubble.setElevation(Ui.dp(this, 10));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Ui.dp(this, 57), Ui.dp(this, 57));
        root.addView(bubble, bp);
        panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 17), Ui.dp(this, 14), Ui.dp(this, 17), Ui.dp(this, 17));
        panel.setBackground(Ui.shape(this, Ui.BG, 19));
        panel.setElevation(Ui.dp(this, 12)); panel.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(this, 305), -2); pp.topMargin = Ui.dp(this, 9);
        root.addView(panel, pp);
        TextView heading = Ui.text(this, "✦  WordBubble AI", 18, Ui.TEXT, true);
        panel.addView(heading, Ui.lp(this, -1, -2, 5));
        status = Ui.text(this, "Ready. Buka game dan tekan Scan.", 12, Ui.MUTED, false);
        panel.addView(status, Ui.lp(this, -1, -2, 13));
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        panel.addView(buttons, Ui.lp(this, -1, Ui.dp(this, 42), 14));
        Button scanButton = Ui.button(this, "⌕  Scan", true);
        LinearLayout.LayoutParams scanLp = new LinearLayout.LayoutParams(0, -1, 1f); scanLp.rightMargin = Ui.dp(this, 7);
        buttons.addView(scanButton, scanLp); scanButton.setOnClickListener(v -> scan());
        autoButton = Ui.button(this, "Auto OFF", false);
        buttons.addView(autoButton, new LinearLayout.LayoutParams(0, -1, 1f));
        autoButton.setOnClickListener(v -> toggleAuto());
        TextView clueTitle = Ui.text(this, "CLUE TERBACA", 11, Ui.BLUE, true);
        panel.addView(clueTitle, Ui.lp(this, -1, -2, 5));
        cluesLabel = Ui.text(this, "Belum scan", 12, Ui.MUTED, false);
        panel.addView(cluesLabel, Ui.lp(this, -1, -2, 13));
        TextView answerTitle = Ui.text(this, "3 CADANGAN PERKATAAN", 11, Ui.BLUE, true);
        panel.addView(answerTitle, Ui.lp(this, -1, -2, 7));
        answerLabel = Ui.text(this, "1.  ...\n2.  ...\n3.  ...", 19, Ui.TEXT, true);
        answerLabel.setLineSpacing(Ui.dp(this, 7), 1f);
        panel.addView(answerLabel, Ui.lp(this, -1, -2, 10));
        Button close = Ui.button(this, "Tutup bubble & hentikan scan", false);
        close.setOnClickListener(v -> stopSelf());
        panel.addView(close, Ui.lp(this, -1, Ui.dp(this, 40), 0));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        winParams = new WindowManager.LayoutParams(
            Ui.dp(this, 57), -2, Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        winParams.gravity = Gravity.TOP | Gravity.LEFT;
        winParams.x = Math.max(0, dm.widthPixels - Ui.dp(this, 79));
        winParams.y = Ui.dp(this, 160);
        windowManager.addView(root, winParams);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY; private int startX, startY; private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=event.getRawX(); downY=event.getRawY(); startX=winParams.x; startY=winParams.y; moved=false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx=event.getRawX()-downX, dy=event.getRawY()-downY;
                        if (Math.abs(dx)>Ui.dp(OverlayService.this, 8) || Math.abs(dy)>Ui.dp(OverlayService.this, 8)) moved=true;
                        if (moved) {
                            winParams.x=Math.max(0, Math.min(startX+(int)dx, dm.widthPixels - (expanded ? Ui.dp(OverlayService.this, 305) : Ui.dp(OverlayService.this, 57))));
                            winParams.y=Math.max(0, Math.min(startY+(int)dy, dm.heightPixels - Ui.dp(OverlayService.this, 64)));
                            windowManager.updateViewLayout(root, winParams);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) setExpanded(!expanded);
                        return true;
                }
                return true;
            }
        });
    }
    private void setExpanded(boolean visible) {
        if (root == null) return;
        expanded=visible; panel.setVisibility(visible ? View.VISIBLE : View.GONE);
        winParams.width=Ui.dp(this, visible ? 305 : 57);
        if (visible) {
            int maxX = getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 305);
            winParams.x=Math.max(0, Math.min(maxX,winParams.x));
        }
        windowManager.updateViewLayout(root,winParams);
    }
    private void updateStatus(String str) { if (status != null) status.setText(str); }
    private void toggleAuto() {
        auto=!auto; autoButton.setText(auto ? "Auto ON" : "Auto OFF");
        handler.removeCallbacks(autoLoop);
        if (auto) {updateStatus("Auto scan setiap " + intervalMs/1000 + " saat"); handler.post(autoLoop);}
        else updateStatus("Auto scan dihentikan");
    }

    private void scan() {
        if (busy || imageReader == null) return;
        busy=true;
        updateStatus("Membaca petunjuk pada skrin...");
        // Hide our own overlay before capturing the game underneath it.
        if (root != null) root.setVisibility(View.INVISIBLE);
        handler.postDelayed(() -> {
            Bitmap screen = null;
            try {
                Image image = imageReader.acquireLatestImage();
                if (image == null) throw new Exception("Imej belum tersedia. Cuba Scan lagi.");
                try {
                    Image.Plane plane = image.getPlanes()[0];
                    ByteBuffer buf = plane.getBuffer();
                    int pixelStride = plane.getPixelStride();
                    int rowStride = plane.getRowStride();
                    int width = image.getWidth(), height = image.getHeight();
                    Bitmap raw = Bitmap.createBitmap(width + (rowStride - pixelStride * width) / pixelStride, height, Bitmap.Config.ARGB_8888);
                    raw.copyPixelsFromBuffer(buf);
                    screen = Bitmap.createBitmap(raw, 0, 0, width, height);
                    raw.recycle();
                } finally { image.close(); }
            } catch (Exception ex) {
                if (root != null) root.setVisibility(View.VISIBLE);
                busy=false; updateStatus("Gagal scan: " + ex.getMessage()); return;
            }
            if (root != null) root.setVisibility(View.VISIBLE);
            final Bitmap bitmap = screen;
            recognizer.process(InputImage.fromBitmap(bitmap,0))
                .addOnSuccessListener(result -> { bitmap.recycle(); handleText(result); })
                .addOnFailureListener(error -> {
                    bitmap.recycle(); busy=false; updateStatus("OCR gagal: " + error.getMessage());
                });
        }, 650);
    }

    private static class ElementRow {
        final String text; final int centerY, left, height;
        ElementRow(String t, Rect r) { text=t; centerY=r.centerY(); left=r.left; height=r.height(); }
    }
    private List<String> collectRows(Text ocr) {
        List<ElementRow> elements = new ArrayList<>();
        for (Text.TextBlock block : ocr.getTextBlocks())
            for (Text.Line line : block.getLines()) {
                // Line is frequently already "burger 2".
                Rect b=line.getBoundingBox();
                if (b != null) elements.add(new ElementRow(line.getText(), b));
                for (Text.Element el : line.getElements()) if (el.getBoundingBox() != null)
                    elements.add(new ElementRow(el.getText(), el.getBoundingBox()));
            }
        Collections.sort(elements, (a,b)->a.centerY!=b.centerY ? Integer.compare(a.centerY,b.centerY) : Integer.compare(a.left,b.left));
        List<String> rows = new ArrayList<>();
        // Individual OCR line results AND recombined horizontal rows allow rank at right to be recognized.
        for (ElementRow e: elements) if (e.text != null) rows.add(e.text);
        for (int i=0; i<elements.size(); i++) {
            ElementRow a=elements.get(i);
            StringBuilder combined = new StringBuilder(a.text);
            int lastX=a.left;
            for (int j=i+1; j<elements.size() && j<=i+10; j++) {
                ElementRow b=elements.get(j);
                if (Math.abs(b.centerY-a.centerY) > Math.max(14, a.height/2+b.height/2)) break;
                if (b.left >= lastX) {combined.append(' ').append(b.text); lastX=b.left;}
            }
            rows.add(combined.toString());
        }
        return rows;
    }
    private void handleText(Text text) {
        List<ClueParser.Clue> clues = ClueParser.parseRows(collectRows(text));
        cluesLabel.setText(ClueParser.format(clues));
        if (clues.isEmpty()) { busy=false; updateStatus("Tiada petunjuk word + rank dikesan. Zoom game dan cuba lagi."); return; }
        updateStatus("Jumpa " + clues.size() + " clue. Menjana 3 cadangan...");
        worker.execute(() -> {
            AiEngine.Result result = AiEngine.predict(getApplicationContext(), clues);
            handler.post(() -> {
                busy=false;
                StringBuilder display = new StringBuilder();
                for (int i=0; i<3; i++) display.append(i+1).append(".  ")
                    .append(i < result.words.size() ? result.words.get(i) : "-")
                    .append(i<2 ? "\n" : "");
                answerLabel.setText(display.toString());
                updateStatus((result.error == null ? "Siap" : result.error) + " • " + result.source);
            });
        });
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        auto=false; handler.removeCallbacksAndMessages(null);
        try { if (root != null && windowManager != null) windowManager.removeView(root); } catch(Exception ignored) {}
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch(Exception ignored) {}
        try { if (imageReader != null) imageReader.close(); } catch(Exception ignored) {}
        try { if (projection != null) projection.stop(); } catch(Exception ignored) {}
        worker.shutdownNow();
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }
}
