package com.wordbubble.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 1004;
    private EditText keyInput;
    private TextView state;
    private final int[] intervals = {8, 15, 30};
    private int intervalIndex = 0;
    private Button intervalButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences p = getSharedPreferences("settings", MODE_PRIVATE);
        int savedInterval = p.getInt("interval", 8);
        for (int i=0; i<intervals.length; i++) if (intervals[i]==savedInterval) intervalIndex=i;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != getPackageManager().PERMISSION_GRANTED)
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 2);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Ui.BG);
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        Ui.verticalPadding(body, this, 25); scroll.addView(body);

        TextView badge = Ui.text(this, "✦  FLOATING GUESS ASSISTANT", 12, Ui.BLUE, true);
        body.addView(badge, Ui.lp(this, -1, -2, 23));
        TextView title = Ui.text(this, "WordBubble\nAI", 40, Ui.TEXT, true);
        title.setLineSpacing(0f, 0.96f); body.addView(title, Ui.lp(this, -1, -2, 15));
        TextView desc = Ui.text(this, "Scan petunjuk dalam permainan dan lihat 3 tekaan. Floating bubble boleh digunakan di atas aplikasi lain.", 15, Ui.MUTED, false);
        desc.setLineSpacing(Ui.dp(this, 4), 1f); body.addView(desc, Ui.lp(this, -1, -2, 24));

        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 18),Ui.dp(this, 19),Ui.dp(this, 18),Ui.dp(this, 18));
        card.setBackground(Ui.shape(this, Ui.PANEL, 20)); body.addView(card, Ui.lp(this, -1, -2, 20));
        TextView setup = Ui.text(this, "TETAPAN AI", 12, Ui.BLUE, true);
        card.addView(setup, Ui.lp(this, -1, -2, 11));
        TextView keyLabel = Ui.text(this, "Gemini API key (pilihan)", 15, Ui.TEXT, true);
        card.addView(keyLabel, Ui.lp(this, -1, -2, 7));
        keyInput = new EditText(this); keyInput.setSingleLine(true); keyInput.setHint("Kosong = mod percuma Datamuse");
        keyInput.setText(p.getString("gemini_key", ""));
        keyInput.setHintTextColor(Ui.MUTED); keyInput.setTextColor(Ui.TEXT);
        keyInput.setTextSize(13); keyInput.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setBackground(Ui.shape(this, Ui.BG, 12));
        card.addView(keyInput, Ui.lp(this, -1, Ui.dp(this, 49), 9));
        TextView keyInfo = Ui.text(this, "Kunci AI disimpan pada peranti. Tanpa kunci, cadangan dibuat melalui perkaitan perkataan percuma. Ia mungkin kurang tepat.", 12, Ui.MUTED, false);
        card.addView(keyInfo, Ui.lp(this, -1, -2, 16));
        intervalButton = Ui.button(this, "Auto scan: setiap " + intervals[intervalIndex] + " saat", false);
        intervalButton.setOnClickListener(v -> {intervalIndex=(intervalIndex+1)%intervals.length; intervalButton.setText("Auto scan: setiap " + intervals[intervalIndex] + " saat");});
        card.addView(intervalButton, Ui.lp(this, -1, Ui.dp(this, 46), 0));

        Button start = Ui.button(this, "✦  Aktifkan floating bubble", true);
        start.setTextSize(16); start.setOnClickListener(v -> startCapture());
        body.addView(start, Ui.lp(this, -1, Ui.dp(this, 57), 12));
        Button stop = Ui.button(this, "Hentikan bubble", false);
        stop.setOnClickListener(v -> {stopService(new Intent(this, OverlayService.class)); state.setText("Bubble dihentikan.");});
        body.addView(stop, Ui.lp(this, -1, Ui.dp(this, 49), 15));
        state = Ui.text(this, "1. Benarkan Display over other apps.\n2. Benarkan rakaman skrin.\n3. Buka game, tekan bubble ✦ dan Scan.", 14, Ui.MUTED, false);
        state.setLineSpacing(Ui.dp(this, 7), 1f); body.addView(state, Ui.lp(this, -1, -2, 20));
        TextView privacy = Ui.text(this, "PRIVASI: OCR dibuat pada telefon. Hanya teks petunjuk dihantar ke perkhidmatan cadangan. Tiada rakaman atau gambar disimpan oleh aplikasi. Scan berhenti apabila bubble dihentikan.", 12, Ui.MUTED, false);
        body.addView(privacy, Ui.lp(this, -1, -2, 9));
        TextView limits = Ui.text(this, "Nota: Android sahaja. Aplikasi yang menyekat screen capture mungkin tidak dapat diimbas. Jawapan ialah tekaan, bukan jaminan nombor 1.", 12, Ui.MUTED, false);
        body.addView(limits);
        setContentView(scroll);
    }

    private void startCapture() {
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putString("gemini_key", keyInput.getText().toString().trim())
            .putInt("interval", intervals[intervalIndex]).apply();
        if (!Settings.canDrawOverlays(this)) {
            state.setText("Sila aktifkan 'Allow display over other apps' untuk WordBubble AI, kemudian kembali dan tekan Aktifkan sekali lagi.");
            Intent settings = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(settings); return;
        }
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), CAPTURE_REQUEST);
        } catch (Exception e) {Toast.makeText(this, "Tidak dapat buka izin screen capture", Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAPTURE_REQUEST) return;
        if (resultCode != RESULT_OK || data == null) {state.setText("Kebenaran screen capture ditolak. Tekan Aktifkan untuk cuba lagi."); return;}
        Intent service = new Intent(this, OverlayService.class);
        service.setAction(OverlayService.ACTION_START);
        service.putExtra("code", resultCode);
        service.putExtra("capture_data", data);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            state.setText("Bubble bermula. Buka game dan tekan ✦.");
            Toast.makeText(this, "Floating bubble diaktifkan", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {state.setText("Gagal aktifkan bubble: " + ex.getMessage());}
    }
}
