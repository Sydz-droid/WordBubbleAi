package com.wordbubble.ai;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class AiEngine {
    public static class Result {
        public final List<String> words;
        public final String source;
        public final String error;
        public Result(List<String> words, String source, String error) { this.words = words; this.source = source; this.error = error; }
    }

    public static Result predict(Context context, List<ClueParser.Clue> clues) {
        SharedPreferences p = context.getSharedPreferences("settings", Context.MODE_PRIVATE);
        String key = p.getString("gemini_key", "").trim();
        if (clues.isEmpty()) return new Result(new ArrayList<>(), "OCR", "Tidak nampak clue. Cuba buka permainan dan Scan semula.");
        if (!key.isEmpty()) {
            try {
                List<String> words = gemini(key, clues);
                if (!words.isEmpty()) return new Result(words, "Gemini AI", null);
            } catch (Exception error) {
                try {
                    List<String> fallback = datamuse(clues);
                    return new Result(fallback, "Cadangan percuma", "AI tidak berjaya: " + friendly(error));
                } catch (Exception ex) {
                    return new Result(new ArrayList<>(), "Rangkaian", friendly(error));
                }
            }
        }
        try { return new Result(datamuse(clues), "Datamuse (percuma)", null); }
        catch (Exception ex) { return new Result(new ArrayList<>(), "Rangkaian", "Tiada internet. " + friendly(ex)); }
    }

    private static String friendly(Exception e) {
        String m = e.getMessage();
        return m == null ? "Ralat sambungan" : m.substring(0, Math.min(95, m.length()));
    }

    private static List<String> gemini(String key, List<ClueParser.Clue> clues) throws Exception {
        StringBuilder hints = new StringBuilder();
        for (ClueParser.Clue c: clues) hints.append(c.word).append(" = rank ").append(c.rank).append("\n");
        String prompt = "You are solving an English semantic word-guessing game similar to Contexto. " +
            "A lower rank is MORE similar to the hidden answer, rank 1 is the secret answer, rank 2 extremely near. " +
            "Here are past guesses and ranks:\n" + hints +
            "Return exactly THREE new single English words or common short phrases most likely to be rank 1. " +
            "NEVER repeat a prior guessed word. Use clues ranked closest as strongest signals, " +
            "also reason from other clues. Return JSON ONLY: {\"words\":[\"...\",\"...\",\"...\"]}. No explanation.";
        JSONObject textPart = new JSONObject().put("text", prompt);
        JSONObject body = new JSONObject()
            .put("contents", new JSONArray().put(new JSONObject().put("parts", new JSONArray().put(textPart))))
            .put("generationConfig", new JSONObject().put("temperature", 0.35)
                .put("responseMimeType", "application/json"));
        HttpURLConnection con = open("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent", "POST");
        con.setRequestProperty("x-goog-api-key", key);
        con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        con.setDoOutput(true);
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream out = con.getOutputStream()) { out.write(bytes); }
        int code = con.getResponseCode();
        String reply = read(code < 400 ? con.getInputStream() : con.getErrorStream());
        con.disconnect();
        if (code >= 400) throw new Exception("Gemini HTTP " + code + " (semak API key / kuota)");
        JSONObject response = new JSONObject(reply);
        JSONArray candidates = response.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) throw new Exception("AI tidak beri cadangan");
        JSONObject first = candidates.getJSONObject(0).getJSONObject("content");
        String raw = first.getJSONArray("parts").getJSONObject(0).optString("text", "").trim();
        JSONObject parsed = new JSONObject(raw);
        JSONArray suggestions = parsed.getJSONArray("words");
        List<String> output = new ArrayList<>();
        Set<String> old = guessed(clues);
        for (int i=0; i<suggestions.length() && output.size()<3; i++) addIfValid(output, old, suggestions.optString(i));
        return output;
    }

    private static List<String> datamuse(List<ClueParser.Clue> clues) throws Exception {
        String nearest = clues.get(0).word;
        String query = URLEncoder.encode(nearest, "UTF-8");
        HttpURLConnection con = open("https://api.datamuse.com/words?ml=" + query + "&max=80", "GET");
        int code = con.getResponseCode();
        if (code >= 400) throw new Exception("Datamuse HTTP " + code);
        JSONArray data = new JSONArray(read(con.getInputStream()));
        con.disconnect();
        Set<String> old = guessed(clues);
        List<String> output = new ArrayList<>();
        for (int i=0; i<data.length() && output.size()<3; i++) addIfValid(output, old, data.getJSONObject(i).optString("word"));
        return output;
    }

    private static Set<String> guessed(List<ClueParser.Clue> clues) {
        Set<String> s = new HashSet<>();
        for (ClueParser.Clue c: clues) s.add(c.word.toLowerCase(Locale.US));
        return s;
    }
    private static void addIfValid(List<String> out, Set<String> old, String word) {
        String w = word.trim().toLowerCase(Locale.US);
        if (!w.matches("[a-z][a-z' -]{1,27}") || old.contains(w) || out.contains(w)) return;
        out.add(w);
    }
    private static HttpURLConnection open(String url, String method) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setRequestMethod(method); con.setConnectTimeout(9000); con.setReadTimeout(15000);
        con.setRequestProperty("Accept", "application/json");
        return con;
    }
    private static String read(InputStream stream) throws Exception {
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder(); String s;
            while ((s = reader.readLine()) != null) b.append(s);
            return b.toString();
        }
    }
    private AiEngine() {}
}
