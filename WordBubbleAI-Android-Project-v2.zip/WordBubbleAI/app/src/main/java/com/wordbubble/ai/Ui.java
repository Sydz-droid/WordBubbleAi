package com.wordbubble.ai;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(17, 23, 35);
    static final int PANEL = Color.rgb(28, 38, 54);
    static final int BLUE = Color.rgb(167, 208, 239);
    static final int TEXT = Color.rgb(246, 248, 252);
    static final int MUTED = Color.rgb(164, 182, 203);
    static final int INK = Color.rgb(17, 28, 46);

    static int dp(Context c, float v) { return (int) (c.getResources().getDisplayMetrics().density * v + 0.5f); }
    static GradientDrawable shape(Context c, int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radius));
        return d;
    }
    static TextView text(Context c, String s, int size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextColor(color); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }
    static Button button(Context c, String label, boolean primary) {
        Button b = new Button(c);
        b.setText(label); b.setTextSize(13); b.setAllCaps(false);
        b.setTextColor(primary ? INK : TEXT);
        b.setBackground(shape(c, primary ? BLUE : PANEL, 14));
        b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        return b;
    }
    static void verticalPadding(View v, Context c, int all) { v.setPadding(dp(c, all), dp(c, all), dp(c, all), dp(c, all)); }
    static LinearLayout.LayoutParams lp(Context c, int width, int height, int bottomDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.bottomMargin = dp(c, bottomDp); return p;
    }
}
