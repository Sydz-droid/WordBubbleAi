package com.wordbubble.ai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ClueParser {
    private static final Pattern ROW = Pattern.compile("^([a-z][a-z' -]{1,29}?)\\s*[:#-]?\\s*(\\d{1,6})$", Pattern.CASE_INSENSITIVE);

    public static final class Clue {
        public final String word;
        public final int rank;
        Clue(String word, int rank) { this.word = word; this.rank = rank; }
        @Override public String toString() { return word + " #" + rank; }
    }

    public static List<Clue> parseRows(List<String> rows) {
        Map<String, Clue> unique = new LinkedHashMap<>();
        for (String text: rows) {
            if (text == null) continue;
            String row = text.trim().toLowerCase(Locale.US)
                .replaceAll("[^a-z0-9' -]", " ").replaceAll("\\s+", " ").trim();
            Matcher match = ROW.matcher(row);
            if (!match.matches()) continue;
            String word = match.group(1).trim();
            try {
                int rank = Integer.parseInt(match.group(2));
                if (rank < 1 || rank > 99999 || word.length() < 2) continue;
                if (word.startsWith("guess") || word.contains("active") || word.contains("score")) continue;
                Clue old = unique.get(word);
                if (old == null || rank < old.rank) unique.put(word, new Clue(word, rank));
            } catch (NumberFormatException ignored) {}
        }
        List<Clue> result = new ArrayList<>(unique.values());
        Collections.sort(result, Comparator.comparingInt((Clue c) -> c.rank));
        if (result.size() > 12) return new ArrayList<>(result.subList(0, 12));
        return result;
    }
    public static String format(List<Clue> clues) {
        if (clues.isEmpty()) return "Tiada petunjuk angka dikesan";
        StringBuilder b = new StringBuilder();
        for (Clue c : clues) { if (b.length() > 0) b.append("  •  "); b.append(c.word).append(" #").append(c.rank); }
        return b.toString();
    }
    private ClueParser() {}
}
